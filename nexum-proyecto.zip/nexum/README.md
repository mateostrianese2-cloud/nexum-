# Nexum — IA y futuro laboral

Sitio estático (HTML + CSS + JavaScript puro). No necesita build ni dependencias.

## Tecnologías
- HTML5 semántico y datos estructurados JSON-LD (schema.org)
- CSS3 (variables, grid, flexbox, `prefers-reduced-motion`)
- JavaScript vanilla (sin frameworks), navegación por hash (`#herramientas`, `#a-slug`)
- Vercel para el hosting (plan gratuito)

## Estructura
```
nexum/
├── index.html        Página principal y metadatos SEO
├── css/styles.css    Estilos y diseño
├── js/data.js        Contenido: herramientas, guías, negocios, niveles, artículos
├── js/app.js         Lógica, vistas, buscador y filtros
├── public/favicon.svg
├── robots.txt
├── sitemap.xml
├── vercel.json       Configuración de Vercel
└── package.json
```

## Ejecutar en tu computadora
Opción A: abrí `index.html` con doble clic.
Opción B (recomendada, con Node.js instalado):
```
npm run dev
```
y abrí la dirección que muestre la terminal.

## Publicar gratis en Vercel
**Con GitHub (recomendado)**
1. Creá un repositorio en github.com y subí esta carpeta.
2. Entrá a vercel.com con tu cuenta de GitHub → **Add New → Project**.
3. Elegí el repositorio. Framework Preset: **Other**. Dejá vacíos Build Command y Output Directory.
4. **Deploy**. Cada cambio que subas a GitHub se publica solo.

**Con la terminal**
```
npm i -g vercel
vercel        # primera vez, vista previa
vercel --prod # publicar
```

## Después de publicar
1. Reemplazá `TU-DOMINIO.vercel.app` por tu dirección real en `robots.txt` y `sitemap.xml`.
2. Registrá el sitio en Google Search Console y enviá `sitemap.xml`.
3. Conectá el newsletter (Mailchimp, Beehiiv o Buttondown): el formulario está en `js/app.js` (constante `NL`) y hoy es solo visual.
4. AdSense: los espacios reservados son `<aside class="ad">` (función `AD` en `js/app.js`). Pegá el código de AdSense cuando te aprueben el sitio.

## Agregar contenido
- Artículo nuevo: sumá una fila al arreglo `A` en `js/data.js` (slug, título, categoría, colores de portada, texto).
- Herramienta, guía u oportunidad: sumá una fila a `T`, `G` o `N`.

## Límites conocidos
- Las URLs usan `#`, por lo que Google indexa sobre todo la portada. Para posicionar cientos de artículos conviene migrar a Astro o Next.js con una página real por artículo.
- Las cifras de la portada provienen del WEF (2025) y del FMI (2024); revisalas cuando salgan nuevas ediciones.
